"""Builds the player page from the factory output (all lessons of one or more graphs)."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from graph_reader import Graph

def pack(graph_path, out_dir, title):
    g = Graph.load(graph_path)
    idx = json.load(open(os.path.join(out_dir, "index.json"), encoding="utf-8"))
    lessons = [json.load(open(os.path.join(out_dir, "lessons", l["lesson_id"], "questions.json"), encoding="utf-8")) for l in idx["lessons"]]
    lessons = [l for l in lessons if l["question_count"]]
    order = {t: i for i, t in enumerate(n["id"] for n in g.data.get("nodes", []))}
    owner = {x["concept_id"]: l["lesson_id"] for l in lessons for x in l["concepts"]}
    links = {}   # (needs, needed) -> how many prerequisite links point that way
    for l in lessons:
        for c in l["concepts"]:
            for p in g.prereq_in.get(c["concept_id"], []):
                if owner.get(p) and owner[p] != l["lesson_id"]:
                    links[(l["lesson_id"], owner[p])] = links.get((l["lesson_id"], owner[p]), 0) + 1
    for l in lessons:   # a lesson waits for another only if MOST links point that way (never a circle of locks)
        l["requires"] = sorted(b for (a, b), k in links.items() if a == l["lesson_id"] and k > links.get((b, a), 0))
    req = {l["lesson_id"]: l["requires"] for l in lessons}
    depth = {}
    def d(lid, seen=()):
        if lid not in depth:
            depth[lid] = 0 if not req[lid] else 1 + max(d(r, seen + (lid,)) for r in req[lid] if r not in seen)
        return depth[lid]
    for l in lessons:
        d(l["lesson_id"])
    lessons.sort(key=lambda l: (depth[l["lesson_id"]], order.get(l.get("topic_id", ""), 0), order.get(l["lesson_id"], 0)))   # the order to learn them
    return {"title": title, "names": {k: c.text for k, c in g.concepts.items()}, "lessons": lessons}

if __name__ == "__main__":
    # python player/build_player.py [graph.json] [output_folder]   (defaults: the test book, output_new)
    root = os.path.dirname(HERE)
    graph_path = os.path.join(root, sys.argv[1]) if len(sys.argv) > 1 else os.path.join(root, "plants_book_graph.json")
    out_dir = os.path.join(root, sys.argv[2]) if len(sys.argv) > 2 else os.path.join(root, "output_new")
    g = Graph.load(graph_path)
    data = {"graphs": [pack(graph_path, out_dir, g.book.get("title", "الكتاب"))]}
    html = open(os.path.join(HERE, "player_template.html"), encoding="utf-8").read().replace("/*DATA*/null", json.dumps(data, ensure_ascii=False))
    out = os.path.join(HERE, "player.html")
    open(out, "w", encoding="utf-8").write(html)
    print("wrote", out, sum(l["question_count"] for g in data["graphs"] for l in g["lessons"]), "questions", "from", os.path.basename(out_dir))
