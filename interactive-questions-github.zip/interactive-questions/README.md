# الأسئلة التفاعلية · Interactive Questions 🌱

**مصنع** بيقرأ جراف الكتاب، ولكل درس **ولكل مفهوم** بيولّد **تحديات تفاعلية شبه ألعاب**، بيفحصها، وبيحفظها مع الدرس. و**مشغّل** بيعرضها ألعاب للطالب (كمبيوتر وتلفون).

**جرّب الألعاب:** افتح [`index.html`](index.html) (أو رابط GitHub Pages تبع الـ repo).

## الملفات
| | |
|---|---|
| [`index.html`](index.html) | صفحة الألعاب (المشغّل) جاهزة، ملف واحد |
| [`ENGINEER_BRIEF_AR.md`](ENGINEER_BRIEF_AR.md) | **للمهندس:** الطلب، الفكرة، كيف بيشتغل، شو بيحتوي |
| [`DYNAMIC_AR.md`](DYNAMIC_AR.md) | **للمهندس:** شو الديناميك بالضبط |
| [`HOW_TO_TRY_AR.md`](HOW_TO_TRY_AR.md) | خطوات التشغيل |
| [`question_factory/`](question_factory) | **الكود:** المصنع، الفحوصات، المشغّل، والشروحات (`CODE_GUIDE_AR.md`، `CHANGES_AR.md`) |
| [`new_structure/`](new_structure) | الجراف التجريبي بالستركشر الجديد + شرحه |
| [`sample/`](sample) | العيّنة الأولى (درس النبات بالرسومات) |

## التشغيل
```
cd question_factory
python -m unittest discover -s tests -t . -v                    # 78 tests OK
python main.py plants_book_graph.json output_new                 # 3 lessons, 52 questions
python player/build_player.py                                    # player/player.html
```
بعد ما تولّد أسئلة جديدة: انسخ `question_factory/player/player.html` مكان `index.html`.

**مع الموديل (اختياري):** حط `ANTHROPIC_API_KEY` بالـ Terminal (مش بملف!) وشغّل `python main.py plants_book_graph.json output_llm --llm`.

## بأرقام
**١٤** نوع تحدي · **٥٢** تحدي بالكتاب التجريبي · **٧٨** فحص للكود · وكل التحديات مجرّبة بالمتصفح وبالإصبع على التلفون.
